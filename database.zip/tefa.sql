-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Agu 2024 pada 12.25
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tefa2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosens`
--

CREATE TABLE `dosens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `nidn` varchar(255) NOT NULL,
  `kelamin` enum('laki-laki','perempuan') NOT NULL,
  `tempat_lahir` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `nomor_telepon` varchar(255) NOT NULL,
  `prodi` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `pangkat` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `dosens`
--

INSERT INTO `dosens` (`id`, `user_id`, `nidn`, `kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `nomor_telepon`, `prodi`, `jabatan`, `pangkat`, `created_at`, `updated_at`) VALUES
(1, 1, '220658302006', 'laki-laki', 'Jambi', '2003-08-29', 'Puri Cantik', '+6289652054473', 'Teknologi Rekayasa Perangkat Lunak', 'Junior Web Developer', 'Mahasiswa', '2024-07-29 17:47:29', '2024-07-29 19:33:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_akhirs`
--

CREATE TABLE `laporan_akhirs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dosen_id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `jenis_laporan_akhir` enum('penelitian kualitatif','penelitian pengembangan','pengabdian masyarakat') NOT NULL,
  `jenis` enum('penelitian','pengabdian') NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `laporan_akhirs`
--

INSERT INTO `laporan_akhirs` (`id`, `dosen_id`, `judul`, `tanggal_upload`, `jenis_laporan_akhir`, `jenis`, `file`, `created_at`, `updated_at`) VALUES
(4, 1, 'Contoh Laporan Akhir 1', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'laporan_akhirs/1722322807_230658302004.pdf', '2024-07-29 22:15:08', '2024-07-29 22:15:08'),
(5, 1, 'Laporan Akhir', '2024-08-01', 'penelitian kualitatif', 'penelitian', 'laporan_akhirs/1722481424_Laporan Data Nasabah.pdf', '2024-07-31 20:03:44', '2024-07-31 20:03:44'),
(6, 1, 'Laporan Akhir', '2024-08-01', 'penelitian kualitatif', 'penelitian', 'laporan_akhirs/1722481461_Laporan Data Nasabah.pdf', '2024-07-31 20:04:21', '2024-07-31 20:04:21'),
(7, 1, 'Laporan Akhir', '2024-08-01', 'pengabdian masyarakat', 'pengabdian', 'laporan_akhirs/1722481505_ProjectBD2 DFD 1.docx', '2024-07-31 20:05:05', '2024-07-31 20:05:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_kemajuans`
--

CREATE TABLE `laporan_kemajuans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dosen_id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `jenis_laporan_kemajuan` enum('penelitian kualitatif','penelitian pengembangan','pengabdian masyarakat') NOT NULL,
  `jenis` enum('penelitian','pengabdian') NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `laporan_kemajuans`
--

INSERT INTO `laporan_kemajuans` (`id`, `dosen_id`, `judul`, `tanggal_upload`, `jenis_laporan_kemajuan`, `jenis`, `file`, `created_at`, `updated_at`) VALUES
(2, 1, 'Contoh Kemajuan 1', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'laporan_kemajuans/1722321793_of teori produksi kelompok 3.pdf', '2024-07-29 21:58:13', '2024-07-29 22:12:14'),
(3, 1, 'Contoh Kemajuan 2', '2024-07-30', 'penelitian kualitatif', 'pengabdian', 'laporan_kemajuans/1722321859_230658302004.pdf', '2024-07-29 21:59:20', '2024-07-29 21:59:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `logbooks`
--

CREATE TABLE `logbooks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dosen_id` bigint(20) UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `kegiatan` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `logbooks`
--

INSERT INTO `logbooks` (`id`, `dosen_id`, `tanggal`, `kegiatan`, `created_at`, `updated_at`) VALUES
(4, 1, '2024-07-30', 'Membantu TEFA Angkatan 2023', '2024-07-29 19:30:20', '2024-07-29 19:30:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_07_29_152749_create_dosens_table', 1),
(6, '2024_07_29_152804_create_proposals_table', 1),
(7, '2024_07_29_152821_create_laporan_kemajuans_table', 1),
(8, '2024_07_29_152833_create_laporan_akhirs_table', 1),
(9, '2024_07_29_152848_create_logbooks_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `proposals`
--

CREATE TABLE `proposals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dosen_id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `jenis_proposal` enum('penelitian kualitatif','penelitian pengembangan','pengabdian masyarakat') NOT NULL,
  `jenis` enum('penelitian','pengabdian') NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `proposals`
--

INSERT INTO `proposals` (`id`, `dosen_id`, `judul`, `tanggal_upload`, `jenis_proposal`, `jenis`, `file`, `created_at`, `updated_at`) VALUES
(2, 1, 'Contoh 2', '2024-07-29', 'pengabdian masyarakat', 'penelitian', 'proposals/1722280816_DAFFACVATS.pdf', '2024-07-29 10:35:16', '2024-07-29 19:25:55'),
(7, 1, 'Contoh 3', '2024-07-30', 'penelitian kualitatif', 'pengabdian', 'proposals/1722303816_POLJAM MART.pdf', '2024-07-29 16:58:36', '2024-07-29 19:26:11'),
(8, 1, 'Contoh 4', '2024-07-30', 'penelitian kualitatif', 'pengabdian', 'proposals/1722312148_230658302004.pdf', '2024-07-29 19:17:28', '2024-07-29 19:26:21'),
(9, 1, 'Contoh 1', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'proposals/1722312612_230658302004.pdf', '2024-07-29 19:25:12', '2024-07-29 19:25:12'),
(10, 1, 'Contoh 5', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'proposals/1722329178_Hanifah A.K - A1A122077 UAS Strategi Pembelajaran Ekonomi.pdf', '2024-07-30 00:01:19', '2024-07-30 00:01:19'),
(11, 1, 'Contoh 6', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'proposals/1722329201_BAB2.pdf', '2024-07-30 00:01:41', '2024-07-30 00:01:41'),
(12, 1, 'Contoh 7', '2024-07-30', 'penelitian kualitatif', 'penelitian', 'proposals/1722329276_230658302004.pdf', '2024-07-30 00:02:56', '2024-07-30 00:02:56'),
(14, 1, 'Proposal Penelitian', '2024-08-01', 'penelitian kualitatif', 'penelitian', 'proposals/1722480433_ppt12-Pengenalan-shell-scripting-di-Linux.pdf', '2024-07-31 19:47:13', '2024-07-31 19:47:13'),
(15, 1, 'Laporan Kegiatan Lab Komputer', '2024-08-01', 'penelitian pengembangan', 'penelitian', 'proposals/1722554364_ProjectBD2 DFD 1.pdf', '2024-08-01 16:19:24', '2024-08-01 16:19:24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Daffa', 'admin@gmail.com', '2024-07-29 17:46:28', '$2y$10$kQb4T/H4rYB45SQ/X6M67ugn74Ku5cFuTBlT10Wdw8NH0SjzZiL3i', 'admin', NULL, '2024-07-29 17:46:28', '2024-07-30 00:20:58'),
(4, 'Ari', 'ari@gmail.com', '2024-07-30 09:07:07', '$2y$10$kQb4T/H4rYB45SQ/X6M67ugn74Ku5cFuTBlT10Wdw8NH0SjzZiL3i', 'user', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dosens`
--
ALTER TABLE `dosens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dosens_user_id_foreign` (`user_id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `laporan_akhirs`
--
ALTER TABLE `laporan_akhirs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `laporan_akhirs_dosen_id_foreign` (`dosen_id`);

--
-- Indeks untuk tabel `laporan_kemajuans`
--
ALTER TABLE `laporan_kemajuans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `laporan_kemajuans_dosen_id_foreign` (`dosen_id`);

--
-- Indeks untuk tabel `logbooks`
--
ALTER TABLE `logbooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `logbooks_dosen_id_foreign` (`dosen_id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposals_dosen_id_foreign` (`dosen_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dosens`
--
ALTER TABLE `dosens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `laporan_akhirs`
--
ALTER TABLE `laporan_akhirs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `laporan_kemajuans`
--
ALTER TABLE `laporan_kemajuans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `logbooks`
--
ALTER TABLE `logbooks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `proposals`
--
ALTER TABLE `proposals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `dosens`
--
ALTER TABLE `dosens`
  ADD CONSTRAINT `dosens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `laporan_akhirs`
--
ALTER TABLE `laporan_akhirs`
  ADD CONSTRAINT `laporan_akhirs_dosen_id_foreign` FOREIGN KEY (`dosen_id`) REFERENCES `dosens` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `laporan_kemajuans`
--
ALTER TABLE `laporan_kemajuans`
  ADD CONSTRAINT `laporan_kemajuans_dosen_id_foreign` FOREIGN KEY (`dosen_id`) REFERENCES `dosens` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `logbooks`
--
ALTER TABLE `logbooks`
  ADD CONSTRAINT `logbooks_dosen_id_foreign` FOREIGN KEY (`dosen_id`) REFERENCES `dosens` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `proposals`
--
ALTER TABLE `proposals`
  ADD CONSTRAINT `proposals_dosen_id_foreign` FOREIGN KEY (`dosen_id`) REFERENCES `dosens` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
